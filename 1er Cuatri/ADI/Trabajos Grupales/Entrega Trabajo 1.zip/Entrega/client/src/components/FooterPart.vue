<script>

</script>

<template>

    <div>
        <hr>
        <br>

        <div class="row">
            <div class="col-6">
                <a href="/books"><h6>Condiciones de uso</h6></a>
            </div>
            <div class="col-6">
                <a href="/books"><h6>Politica de privacidad</h6></a>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <a href="/books"><h6>Politica de cookies</h6></a>
            </div>
            <div class="col-6">
                <a href="/books"><h6>Nuestro Blog</h6></a>
            </div>
        </div>
        <div class="row">
            <div class="col-6">
                <a href="/books"><h6>Contactar</h6></a>
            </div>
            <div class="col-6">
                <a href="/books"><h6>Sobre UApenBook</h6></a>
            </div>
        </div>
        <br>
        <hr>
    </div>
</template>

<style scoped>
.row{
    margin: auto;
}

</style>