const SECRET = '123456543210'

module.exports={
    SECRET
}