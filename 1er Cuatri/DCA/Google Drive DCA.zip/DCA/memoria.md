### Nikita Polyanskiy Y4441167L

# Vim

## Tiempos de ejecución

### sin ccache

make -j1:
real	1m37,673s
user	1m17,660s
sys	0m19,276s


make -j2:
real	1m6,717s
user	1m46,860s
sys	0m23,617s


make -j3:
real	1m2,356s
user	2m30,249s
sys	0m30,154s


make -j4:
real	0m53,586s
user	2m29,179s
sys	0m46,025s


make -j5:
real	1m0,350s
user	2m48,241s
sys	0m47,851s




### con ccache

make -j1:
real	1m47,170s
user	1m20,403s
sys	0m25,348s

real	0m16,152s
user	0m10,614s
sys	0m4,659s


make -j4:
real	1m8,038s
user	2m56,739s
sys	0m57,172s

real	0m3,894s
user	0m6,657s
sys	0m4,294s







