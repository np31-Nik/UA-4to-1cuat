### Nikita Polyanskiy Y4441167L

# Vim

## Tiempos de ejecución

### sin ccache

make -j1:
real	2m32,701s
user	2m12,224s
sys	0m16,824s

make -j2:
real	1m58,011s
user	3m8,052s
sys	0m32,319s

make -j3:
real	1m37,032s
user	3m18,282s
sys	0m53,081s

make -j4:
real	1m33,744s
user	3m26,395s
sys	1m20,779s

make -j5:
real	1m39,491s
user	3m36,941s
sys	1m26,273s

make -j6:
real	2m7,649s
user	2m58,941s
sys	1m11,124s

### con ccache

make -j1:
real	1m51,920s
user	1m32,117s
sys	0m17,605s

make -j2:
real	0m10,287s
user	0m11,747s
sys	0m6,095s

make -j3:
real	0m8,014s
user	0m13,536s
sys	0m5,994s

make -j4:
real	0m6,925s
user	0m12,373s
sys	0m6,378s

make -j5:
real	0m12,389s
user	0m17,505s
sys	0m8,865s



