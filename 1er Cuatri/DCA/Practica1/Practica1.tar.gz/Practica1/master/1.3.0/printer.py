lang = input("Elige un idioma: ES, EN, IT, VAL\n")

if lang=="ES":
    print("Hola mundo")
    input("Presiona la tecla Enter para continuar...")

elif lang=="EN":
    print("Hello world")
    input("Press the Enter key to continue...")


elif lang=="IT":
    print("Ciao mondo")
    input("Premi il tasto Invio per continuare...")

elif lang=="VAL":
    print("Hola món")
    input("Pressiona la tecla *Enter per a continuar...")

input("Presiona la tecla Enter para continuar...")

