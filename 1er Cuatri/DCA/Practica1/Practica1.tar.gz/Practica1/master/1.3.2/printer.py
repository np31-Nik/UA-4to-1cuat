lang = input("Elige un idioma: ES, EN, IT, VAL\n")

if lang=="ES":
    print("Hola mundo")
    input("Presiona la tecla Enter para continuar...")
    print("Adios")

elif lang=="EN":
    print("Hello world")
    input("Press the Enter key to continue...")
    print("Goodbye")

elif lang=="IT":
    print("Ciao mondo")
    input("Premi il tasto Invio per continuare...")
    print("Arrivederci")

elif lang=="VAL":
    print("Hola món")
    input("Pressiona la tecla *Enter per a continuar...")
    print("Adeu")