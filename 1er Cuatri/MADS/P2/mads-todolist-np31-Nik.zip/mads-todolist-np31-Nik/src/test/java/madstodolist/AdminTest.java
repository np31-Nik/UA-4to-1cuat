package madstodolist;

import madstodolist.model.Usuario;
import madstodolist.model.UsuarioRepository;
import madstodolist.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;

import java.text.SimpleDateFormat;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
@AutoConfigureMockMvc
@Sql(scripts = "/clean-db.sql", executionPhase = AFTER_TEST_METHOD)
public class AdminTest {
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private UsuarioService usuarioService;

    Long addAdmin() {
        Usuario usuario = new Usuario("admin@admin.ua");
        usuario.setNombre("admin");
        usuario.setPassword("admin");
        usuario.setAdmin(true);
        usuario = usuarioService.registrar(usuario);
        return usuario.getId();
    }

    @Test
    public void crearAdmin(){

        Usuario usuario = new Usuario("juan.gutierrez@gmail.com");

        usuario.setNombre("Juan Gutiérrez");
        usuario.setPassword("12345678");
        usuario.setAdmin(true);

        assertThat(usuario.getEmail()).isEqualTo("juan.gutierrez@gmail.com");
        assertThat(usuario.isAdmin()).isEqualTo(true);
    }

    @Test
    public void checkboxAdmin() throws Exception {
        this.mockMvc.perform(get("/registro"))
                .andExpect(content().string(containsString("Admin: ")));
    }

    @Test
    public void adminExiste() throws Exception {
        addAdmin();
        this.mockMvc.perform(get("/registro"))
                .andExpect(content().string(not(containsString("Admin: "))));
    }



}
