package madstodolist;

import madstodolist.authentication.ManagerUserSession;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import javax.servlet.http.HttpSession;

import java.util.*;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.context.jdbc.Sql.ExecutionPhase.AFTER_TEST_METHOD;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
@AutoConfigureMockMvc
@Sql(scripts = "/clean-db.sql", executionPhase = AFTER_TEST_METHOD)
public class ListadoUsuariosTest {

    @MockBean
    private MockHttpSession session;
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    UsuarioService usuarioService;

    //String nombre = "Juan";
    @MockBean
    private ManagerUserSession managerUserSesion;

   /* Long addUsuarioBD() {
        Usuario usuario = new Usuario("user@ua");
        usuario.setNombre(nombre);
        usuario.setPassword("123");
        usuario = usuarioService.registrar(usuario);
        return usuario.getId();
    }*/

  /*  void loginAdmin(){
        Usuario admin = new Usuario();
        admin.setNombre("admin");
        admin.setEmail("admin@ua.es");
        admin.setPassword("admin");
        admin.setAdmin(true);
        admin = usuarioService.registrar(admin);
        managerUserSesion.logearUsuario(admin.getId());
    }*/
    @Test
    public void testTitulo() throws Exception {
        Usuario admin = new Usuario();
        admin.setNombre("admin");
        admin.setEmail("admin@ua.es");
        admin.setPassword("admin");
        admin.setAdmin(true);
        when(usuarioService.comprobarLogin(session)).thenReturn(admin);
        when(managerUserSesion.usuarioLogeado()).thenReturn(admin.getId());

        this.mockMvc.perform(get("/registrados").session(session))
                .andExpect(content().string(containsString("Listado de Usuarios")));
    }

    @Test
    public void testNuevoUsuario() throws Exception{
        Usuario admin = new Usuario();
        admin.setNombre("admin");
        admin.setEmail("admin@ua.es");
        admin.setPassword("admin");
        admin.setAdmin(true);



        List<Usuario> lista= new ArrayList<>();
        Usuario u1 = new Usuario();
        u1.setEmail("user@ua");
        lista.add(u1);

        when(usuarioService.findAll()).thenReturn(lista);
        when(usuarioService.comprobarLogin(session)).thenReturn(admin);
        when(managerUserSesion.usuarioLogeado()).thenReturn(admin.getId());
        this.mockMvc.perform(get("/registrados").session(session))
                .andExpect(content().string(containsString("user@ua")));
    }

    @Test
    public void detallesUsuario() throws Exception {
        Usuario admin = new Usuario();
        admin.setNombre("admin");
        admin.setEmail("admin@ua.es");
        admin.setPassword("admin");
        admin.setAdmin(true);

        Usuario u1 = new Usuario();
        u1.setEmail("user@ua");
        when(managerUserSesion.usuarioLogeado()).thenReturn(admin.getId());
        when(usuarioService.comprobarLogin(session)).thenReturn(admin);
        when(usuarioService.findById(1L)).thenReturn(u1);

        this.mockMvc.perform(get("/registrados/"+1L).session(session))
                .andExpect(content().string(containsString("user@ua")));
    }
}
