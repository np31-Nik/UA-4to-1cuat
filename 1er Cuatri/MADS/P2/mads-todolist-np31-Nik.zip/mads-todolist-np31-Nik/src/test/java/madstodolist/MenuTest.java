package madstodolist;

import madstodolist.authentication.ManagerUserSession;
import madstodolist.model.Usuario;
import madstodolist.service.UsuarioService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
@AutoConfigureMockMvc
public class MenuTest {

    @Autowired
    private MockMvc mockMvc;
    @Autowired
    UsuarioService usuarioService;

    @MockBean
    ManagerUserSession managerUserSession;

    @Test
    public void testGuest() throws Exception {

        this.mockMvc.perform(get("/about"))
                .andExpect(content().string(containsString("login")));
    }

    @Test
    public void testLogeado() throws Exception {
        Usuario usuario = new Usuario("user@ua");
        usuario.setPassword("123");
        usuario.setNombre("Juan");
        usuario = usuarioService.registrar(usuario);
        managerUserSession.logearUsuario(usuario.getId());
        when(managerUserSession.usuarioLogeado()).thenReturn(usuario.getId());

        this.mockMvc.perform(get("/about"))
                .andExpect(content().string(containsString(usuario.getNombre())));
    }



}
