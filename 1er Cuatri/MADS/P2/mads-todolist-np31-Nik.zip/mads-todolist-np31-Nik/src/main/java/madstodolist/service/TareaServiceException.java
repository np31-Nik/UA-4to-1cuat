package madstodolist.service;

public class TareaServiceException extends RuntimeException {

    public TareaServiceException(String message) {
        super(message);
    }
}
