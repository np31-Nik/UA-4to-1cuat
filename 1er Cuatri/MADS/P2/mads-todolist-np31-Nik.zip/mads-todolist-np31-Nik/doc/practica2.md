### Nikita Polyanskiy Y4441167L
# Práctica 2
## Cambios de clases
### Controladores

- **HomeController**: Se ha creado un controlador para la página 'Acerca De' ('/about').
- **UserController**: Se ha creado un controllador para las páginas de listado de usuarios ('/registrados') y detalles de usuario ('/registrados/{id}'). En este mismo se comprueba que el usuario actual es admin antes de permitir el acceso a dichas paginas, si no lo es, se lanzara una excepcion 'NoAutorizadoException':
```
    private void comprobarAdmin(Usuario user) {
        if(!user.isAdmin()){
            throw new NoAutorizadoException();
        }
    }
    @GetMapping("/registrados")
    public String listaUsuarios(Model model, HttpSession session){
        Usuario user = usuarioService.comprobarLogin(session);
        comprobarAdmin(user);

        model.addAttribute("user",user);
        
        List<Usuario> users = usuarioService.findAll();
        model.addAttribute("users",users);
        return "listaUsuarios";
    }
```

- **LoginController**: Se ha modificado el metodo de 'registroForm', para realizar la comprobacion de si existe un usuario admin, y pasarle el resultado al formulario, como se puede ver en el codigo a continuacion. Y tambien se ha modificado el metodo de 'registroSubmit' para tener en cuenta el nuevo atributo de admin del usuario.
```
@GetMapping("/registro")
  public String registroForm(Model model) {
  model.addAttribute("registroData", new RegistroData());
  boolean existeAdmin=false;
  List<Usuario> lista = usuarioService.findAll();
  for(int i = 0; i<lista.size();i++){
  if (lista.get(i).isAdmin()){
  existeAdmin=true;
  break;
  }
  }
  model.addAttribute("existeAdmin",existeAdmin);
  return "formRegistro";
  }
 ```

- **RegistroData**: Se han añadido atributos y metodos para el atributo admin del usuario.

### Modelos
- **Usuario**: Se ha añadido el atributo de admin (bool).

### Servicios
- **UsuarioService**: Se han añadido 2 metodos, un 'findAll' para devolver un listado de todos los usuarios, y un 'comprobarLogin', para obtener los datos del usuario actual.

### Excepciones
- **'NoAutorizadoException'**: Una clase simple que lanza una excepcion con codigo de estado "Unauthorized".
```
@ResponseStatus(value = HttpStatus.UNAUTHORIZED, reason="Usuario no autorizado")
  public class NoAutorizadoException extends RuntimeException {
  }
```

## Recursos
### Plantillas
En general, se ha añadido una barra de menu a todas las plantillas, que depende de si el usuario ha iniciado sesion. Se le debe pasar el objeto del usuario a la plantilla, en caso de que no se pase o si es nulo, aparecera el menu de invitados. En el menu del usuario aparecera su nombre y su id, como se puede ver a continuacion en el codigo:
```
<th:block th:if="${user!=null}">
  <div th:replace="fragments :: navbar1(userName=${user} ? ${user.getNombre()} : '',
          userId=${user} ? ${user.getId()} : '')"></div>
</th:block>
<th:block th:if="${user == null}">
  <div th:replace="fragments :: navbar2"></div>
</th:block>

```
 
- **'about'**: Una página con la informacion acerca de nuestra aplicaicon.
- **'detallesUsuario'**: Página con la informacion relacionada a un usuario.
- **'formRegistro'**: Se ha añadido una condicion para mostrar el checkbox del atributo admin, dependiendo de la variable 'existeAdmin' pasada por el controlador.
```
<th:block th:if="${existeAdmin == false}">
    <div class="form-group">
        <label>Admin: </label>
        <input type="checkbox" name="admin"/>
    </div>
</th:block>
```
- **'fragments'**: Se han añadido 2 tipos de barra de menu, navbar1 y navbar2, una para el usuario logeado, otra para el invitado.
- **'listaUsuarios'**: Muestra un listado de todos los usuarios registrados.
### Otros
Se ha modificado 'data.sql' para tener en cuenta el nuevo atributo del usuario (admin).
```
INSERT INTO usuarios (id, email, nombre, password, fecha_nacimiento,admin) VALUES('1', 'user@ua', 'Usuario Ejemplo', '123', '2001-02-10',false);
```

## Tests
- **'AcercaDeWebTest**: Se han implementado 2 metodos de test para comprobar que el contenido mostrado en la pagina '/about' es correcto.
- **'ListadoUsuariosTest'**: Se han implementado 3 tests, uno para comprobar el acceso a la pagina y su contenido, otro para comprobar que se visualizen los datos de un nuevo usuario creado, y otro para comprobar que la informacion mostrada en la pagina de detalles de usuario sea la correcta. Todos estos metodos tambien tienen en cuenta que el usuario debe ser administrador para poder acceder a estas paginas.
- **'MenuTest'**: Se han implementado 2 metodos de test, para comprobar que el menu muestra la informacion correcta tanto para invitado como para el usuario logeado.
- **'AdminTest'**: Se han implementado 3 tests, para comprobar la creacion de un usuario admin, la visibilidad del checkbox del atributo admin en la pagina de registro, y si ya existe un usuario admin, que ese checkbox no aparezca.


## Repositorios
- Github: https://github.com/mads-ua-22-23/mads-todolist-np31-Nik