package demoapp;

import demoapp.service.SaludoService;
import demoapp.service.StringService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
public class ServiceTest {

    @Autowired
    SaludoService saludo;

    @Autowired
    StringService string;
    @Test
    public void contexLoads() throws Exception {
        assertThat(saludo).isNotNull();
        assertThat(string).isNotNull();
    }

    @Test
    public void serviceSaludo() throws Exception {
        assertThat(saludo.saluda("Domingo")).isEqualTo("Hola Domingo");
    }

    @Test
    public void serviceString() throws Exception{
        assertThat(string.countNumbers("2Hol0a9")).isEqualTo("3");
    }
}
