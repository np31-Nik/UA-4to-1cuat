package demoapp.controller;

import org.springframework.stereotype.Controller;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class StringData {
    @NotBlank
    String string;

    public void setString(String s){
        string=s;
    }

    public String getString(){
        return string;
    }
}
