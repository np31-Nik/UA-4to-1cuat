package demoapp.service;

import org.springframework.stereotype.Service;

import static java.lang.Character.isDigit;

@Service
public class StringService {
    public String countNumbers(String s){
        int nums = 0;
        for(int i = 0; i<s.length();i++){
            if(isDigit(s.charAt(i))){
                nums++;
            }
        }
        return String.valueOf(nums);
    }
}
