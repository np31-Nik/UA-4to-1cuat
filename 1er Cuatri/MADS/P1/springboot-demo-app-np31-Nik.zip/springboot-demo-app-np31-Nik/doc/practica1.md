#### Nikita Polyanskiy Y4441167L
# Práctica 1

## Funcionalidad implementada
La funcionalidad que se ha implementado es un **contador de digitos** de un string introducido por el usuario.
Para acceder a esta funcionalidad se debe entrar en la pagina **'/stringform'** (plantilla **'formString.html'**), luego introducimos un string cualquiera (se ha hecho validación en **'StringData.java'** para que no se pueda pasar una cadena vacia, usando @NotBlank), y al darle al botón, una vez validados los datos, nos redirige a la página **'/countedstring'** (plantilla **'countedString.html'**), donde nos imprimirá por pantalla el string que hemos introducido, y la cantidad de digitos dentro de dicho string.

La implementacion de Get y Post de la página **'/stringform'** se ha hecho en el controlador 'StringControllerForm.java', dentro de la función de Post, se llama a la función **'countNumbers'** de la clase servicio **'StringService.java'**, para contar los digitos del string introducido, y nos devuelve la cantidad de digitos.

## Tests

Para comprobar el funcionamiento correcto de mi funcionalidad, he realizado 2 tests. 

Primero un test para la clase servicio **'StringService'**, esta función de test se encuentra en el fichero **'ServiceTest.java'**

```
    @Test
    public void serviceString() throws Exception{
        assertThat(string.countNumbers("2Hol0a9")).isEqualTo("3");
    }
```

Y otro test de la capa de presentación, para comprobar que el resultado final que se imprime por pantalla es el esperado. Se encuentra en **'MockMvcTest.java'**.

```
    @Test
    public void stringPostResponse() throws Exception{
        this.mockMvc.perform(post("/stringform")
                .param("string","hol29"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Tu string (hol29) tiene 2 digitos.")));
    }
```



## Repositorios
- Docker: https://hub.docker.com/repository/docker/np31/spring-boot-demoapp
- Github: https://github.com/mads-ua-22-23/springboot-demo-app-np31-Nik